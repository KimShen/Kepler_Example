package com.kepler.demo.start;

public interface HelloWorld {

	public String hello();
}
